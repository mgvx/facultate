This folder contains libraries from other projects and parties. For 3rd party libraries a license is provided
as a LICENSE.* file, please read these files. At the moment it contains:

tockit-*.jar: 
  part of our Tockit project (http://www.tockit.org, same licence as ToscanaJ)

jdom.jar: 
  JDOM, beta 9 (http://www.jdom.org, licence in LICENSE.jdom)

hsqldb.jar: 
  HSQL Database Engine, version 1.8.0.2 (http://hsqldb.sourceforge.net/, license in LICENSE.hsqldb.html)
 
commons-cli.jar:
  Command line parser from the Jakarta Commons project, version 1.0 (http://jakarta.apache.org/commons/), license in LICENSE.apache.txt
  
ant-contrib.jar
  Ant extras - used in plugins deployment, 0.3 (http://sourceforge.net/projects/ant-contrib/, license in LICENSE-ant-contrib.txt)
