#!/bin/sh
ulimit -s 2048
java -jar Siena.jar
